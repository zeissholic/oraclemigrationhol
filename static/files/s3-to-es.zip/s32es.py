import boto3
import json
import os
import re
import requests
import datetime
import geoip2.database
from requests_aws4auth import AWS4Auth


region = os.environ['ES_REGION'] 
service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

host = os.environ['ES_HOST']
index = os.environ['ES_INDEX']
type = 'logs'
url = host + '/' + index + '/' + type

headers = { "Content-Type": "application/json" }

s3 = boto3.client('s3')

# Regular expressions used to parse some simple log lines
ip_pattern = re.compile('(\d+\.\d+\.\d+\.\d+)')
time_pattern = re.compile('\[(\d+\/\w\w\w\/\d\d\d\d:\d\d:\d\d:\d\d\s.\d\d\d\d)\]')
# message_pattern = re.compile('\"(.+)\"')
status_pattern = re.compile('\" (\d\d\d) ')
bytes_pattern = re.compile(' (\d{1,}?) "')

#agent_pattern = re.compile('\" \"(.*?)\"$')
request_pattern = re.compile('\] \"(.*?)\" ')

def myconverter(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()
                    
                    
# Lambda execution starts here
def handler(event, context):
    for record in event['Records']:

        # Get the bucket name and key for the new file
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # Get, read, and split the file into lines
        obj = s3.get_object(Bucket=bucket, Key=key)
        body = obj['Body'].read().decode('utf-8')
        lines = body.splitlines()

        # Match the regular expressions to each line and index the JSON
        for line in lines:
            
            #agent_s = agent_pattern.search(line).group(1)
            ips = ip_pattern.findall(line)
            
            

            #if agent_s == "ELB-HealthChecker/2.0":
            #    continue

            #if ip[0:3] == "10." or ip[0:4] == "172." or ip[0:8] == "192.168.":
            #    continue
            if len(ips) > 1:
                ip = ips[1]
            else:
                continue
            print("IP:"+ip)
            # message = message_pattern.search(line).group(1)
            request_s = request_pattern.search(line).group(1)
            status_s = status_pattern.search(line).group(1)
            
            
            format = '%d/%b/%Y:%H:%M:%S %z'
            datestring = time_pattern.search(line).group(1)
            timestamp = datetime.datetime.strptime(datestring, format).isoformat()
            
            
            try:
                bytes_s = int(bytes_pattern.search(line).group(1))
            except:
                bytes_s = 0

            request_list = request_s.split( )
            verb_s = request_list[0]
            url_s = request_list[1]
            protocol_s = request_list[2]

        
            #document = { "source_ip": ip, "accesstime": timestamp, "request": request_s, "httpcode": status_s, "transferred": bytes_s, "agent": agent_s, "verb": verb_s, "url": url_s, "protocol": protocol_s}
            document = { "source_ip": ip, "accesstime": timestamp, "httpcode": status_s, "transferred": bytes_s, "verb": verb_s, "url": url_s, "protocol": protocol_s}
            
            reader = geoip2.database.Reader('GeoLite2-City.mmdb')    
            res = reader.city(ip)
            document["city"] = res.city.name
            document["country"] = res.country.iso_code
            document["location"] = str(res.location.latitude)+","+str(res.location.longitude)
            document["latitude"] = res.location.latitude
            document["longitude"] = res.location.longitude
            reader.close()

            print(document)
            try:
                r = requests.post(url, auth=awsauth, json=document, headers=headers)
            
            except requests.exceptions.RequestException as e:  
                print (e.message)
